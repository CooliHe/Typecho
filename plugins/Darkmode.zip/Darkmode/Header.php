<?php

/**
 * 
 * @package Darkmode
 * @authors 任宝硕(www.baoshuo.ren), 王公子(www.me.sb)
 */

/** 获取配置 */
$mode        = Helper::options()->plugin( 'Darkmode' )->mode;
$start       = Helper::options()->plugin( 'Darkmode' )->start;
$end         = Helper::options()->plugin( 'Darkmode' )->end;
$chrome      = Helper::options()->plugin( 'Darkmode' )->chrome;
$sun         = Helper::options()->plugin( 'Darkmode' )->sun;
$moon        = Helper::options()->plugin( 'Darkmode' )->moon;
$alicestyle  = Helper::options()->plugin( 'Darkmode' )->alicestyle[0];
$kirinkhiki  = Helper::options()->plugin( 'Darkmode' )->kirinkhiki[0];
$footer      = Helper::options()->plugin( 'Darkmode' )->footer[0];
$phonebutton = Helper::options()->plugin( 'Darkmode' )->phonebutton;

if ( $mode != 'never' ) {
    
    /** 设定按钮图标颜色 */
    if ( ! empty( trim( $sun ) ) ) {
        echo '<!-- Darkmode Plugin v' . PINFO['version'] . ' - Sun Color -->';
        echo '<style>.icon-dark-mode {position:relative; top:3px; color:' . trim( $sun ) . '!important;}</style>';
    }
    if ( ! empty( trim( $moon ) ) ) {
        echo '<!-- Darkmode Plugin v' . PINFO['version'] . ' - Moon Color -->';
        echo '<style>.icon-light-mode{position:relative; top:3px; color:' . trim( $moon ) . '!important;}</style>';
    }
    
    /** 引入 CSS */
    echo '<!-- Darkmode Plugin v' . PINFO['version'] . ' - Darkmode CSS -->';
    echo '<link rel="stylesheet" href="' . Helper::options()->pluginUrl . '/Darkmode/darkmode.min.css" type="text/css" />';
    
    /** Android Chrome 地址栏颜色 */
    if ( ! empty( trim($chrome) ) ) {
        echo '<!-- Darkmode Plugin v' . PINFO['version'] . ' - Chrome Color -->';
        echo '<script>if(new Date().getHours()>=' . $start . '||new Date().getHours()<=' . $end . '){var meta = document.getElementsByTagName(\'meta\');meta["theme-color"].setAttribute(\'content\', \'' . $chrome .'\');}</script>';
    }
    
    /** AliceStyle 适配 */
    if ( $alicestyle === 'on' ) {
        echo '<!-- Darkmode Plugin v' . PINFO['version'] . ' - AliceStyle -->';
        echo '<link rel="stylesheet" href="' . Helper::options()->pluginUrl . '/Darkmode/AliceStyle.min.css" type="text/css" />';
    }
    
    /** KirinShiKi 适配 */
    if ( $kirinkhiki === 'on') {
        echo '<!-- Darkmode Plugin v' . PINFO['version'] . ' - KirinShiKi -->';
        echo '<link rel="stylesheet" href="' . Helper::options()->pluginUrl . '/Darkmode/kirin.min.css" type="text/css" />';
    }
    
    /** 页脚美化适配 */
    if ( $footer === 'on' ) {
        echo '<!-- Darkmode Plugin v' . PINFO['version'] . ' - Footer -->';
        echo '<style>.night .app-footer {background: #000!important;}</style>';
    }
    
    /** 移动端图标位置 */
    if ( $phonebutton === 'headnav' ) {
        echo '<!-- Darkmode Plugin v' . PINFO['version'] . ' - Mobile Icons Style -->';
        echo '<style>#header>.navbar-header>button:nth-child(2){position:absolute;right:40px;top:0px;} @media (max-width: 767px) { .nav-switch-dark-mode.for-desktop { display: none!important; } }</style>';
    } else {
        echo '<!-- Darkmode Plugin v' . PINFO['version'] . ' - Mobile Icons Style -->';
        echo '<style>.nav-switch-dark-mode.for-desktop {display: block!important;}</style>';
    }
    
}

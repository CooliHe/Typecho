<?php

$modeText = '我们建议选择 <code style="padding: 2px 4px; font-size: 90%; color: #c7254e; background-color: #f9f2f4; border-radius: 4px;">定时开启</code> ，若您偏爱暗色主题，也可以选择 <code style="padding: 2px 4px; font-size: 90%; color: #c7254e; background-color: #f9f2f4; border-radius: 4px;">始终开启</code> ，若您选择 <code style="padding: 2px 4px; font-size: 90%; color: #c7254e; background-color: #f9f2f4; border-radius: 4px;">由访问者 Cookies 决定</code> ，则需手动开启或关闭，您也可以选择 <code style="padding: 2px 4px; font-size: 90%; color: #c7254e; background-color: #f9f2f4; border-radius: 4px;">从不开启</code> ，此选项仅用于需要禁用此插件，又不想丢失您已有的设置选项时使用。';
$startText = '日落的时间一般为下午 6 点 30 分 到 7 点，我们建议您将此选项设置为 <code style="padding: 2px 4px; font-size: 90%; color: #c7254e; background-color: #f9f2f4; border-radius: 4px;">21</code>，也就是晚上 9 点';
$endText = '太阳升起的时间一般为 5 点到 6 点，但我们建议您将此选项设置为 <code style="padding: 2px 4px; font-size: 90%; color: #c7254e; background-color: #f9f2f4; border-radius: 4px;">7</code>，太阳刚刚升起，较早的启用亮色会些许刺眼';
$chromeText = '输入一个 HEX 颜色值，例如 <code style="padding: 2px 4px; font-size: 90%; color: #c7254e; background-color: #f9f2f4; border-radius: 4px;">#000000</code>，若您不想设置，请留空';
$sunText = '输入一个 HEX 颜色值，例如 <code style="padding: 2px 4px; font-size: 90%; color: #c7254e; background-color: #f9f2f4; border-radius: 4px;">#ffc107</code>，留空则会使用默认配色';
$moonText = '输入一个 HEX 颜色值，例如 <code style="padding: 2px 4px; font-size: 90%; color: #c7254e; background-color: #f9f2f4; border-radius: 4px;">#000000</code>，留空则会使用默认配色';
$alicestyleText = '若你在用 <code style="padding: 2px 4px; font-size: 90%; color: #c7254e; background-color: #f9f2f4; border-radius: 4px;">AliceStyle</code> 插件，请开启此选项';
$kirinshikiText = '若你在用 <code style="padding: 2px 4px; font-size: 90%; color: #c7254e; background-color: #f9f2f4; border-radius: 4px;">KirinShiKi</code> 插件，请开启此选项';
$footerText = '若网站的页脚在夜间模式并未变更为暗色，请开启此选项';

$mode        = new Typecho_Widget_Helper_Form_Element_Select( 'mode', [ 'time' => '定时开启', 'always' => '始终开启', 'never' => '从不开启', 'cookie' => '由访问者 Cookies 决定' ], 'time', _t( '你希望在何时启用夜间模式' ), _t( $modeText . '<br><hr>' ) );
$start       = new Typecho_Widget_Helper_Form_Element_Text( 'start', NULL, _t( '21' ), _t( '开始时间（24 小时格式）' ), _t( $startText ) );
$end         = new Typecho_Widget_Helper_Form_Element_Text( 'end', NULL, _t( '7' ), _t( '结束时间（24 小时格式）' ), _t( $endText . '<br><hr>' ) );
$chrome      = new Typecho_Widget_Helper_Form_Element_Text( 'chrome', NULL, NULL, _t( '夜间模式下安卓 Chrome 地址栏颜色' ), _t( $chromeText . '<br><hr>' ) );
$sun         = new Typecho_Widget_Helper_Form_Element_Text( 'sun', NULL, _t( '#ffc107' ), _t( '太阳图标颜色' ), _t( $sunText ) );
$moon        = new Typecho_Widget_Helper_Form_Element_Text( 'moon', NULL, _t( '#0e90d2' ), _t( '月亮图标颜色' ), _t( $moonText . '<br><hr>' ) );
$alicestyle  = new Typecho_Widget_Helper_Form_Element_Checkbox( 'alicestyle', [ 'on' => _t( 'AliceStyle 适配' ) ], _t( ' ' ), _t( '三方适配' ), _t( $alicestyleText ) );
$kirinshiki  = new Typecho_Widget_Helper_Form_Element_Checkbox( 'kirinshiki', [ 'on' => _t( 'KirinShiKi 适配' ) ], _t( ' ' ), _t( '三方适配' ), _t( $kirinshikiText ) );
$footer      = new Typecho_Widget_Helper_Form_Element_Checkbox( 'footer', [ 'on' => _t( '页脚美化适配' ) ], _t( ' ' ), _t(' '), _t( $footerText . '<br><hr>' ) );
$phonebutton = new Typecho_Widget_Helper_Form_Element_Select( 'phonebutton', [ 'headnav' => '顶栏', 'menu' => '顶栏下拉菜单' ], 'headnav', _t( '移动端切换按钮位置' ), _t( '我们建议将按钮放在顶栏中<br><hr>' ) );


$form->addInput( $mode );
$form->addInput( $start );
$form->addInput( $end );
$form->addInput( $chrome );
$form->addInput( $sun );
$form->addInput( $moon );
$form->addInput( $alicestyle );
$form->addInput( $kirinshiki );
$form->addInput( $footer );
$form->addInput( $phonebutton );

echo <<<EOF
<script>
    setInterval(function() {
    if(document.getElementById('check')) {
	    document.getElementById('typecho-option-item-mode-1').style.display='none';
	    document.getElementById('typecho-option-item-start-2').style.display = 'none';
	    document.getElementById('typecho-option-item-end-3').style.display = 'none';
	    document.getElementById('typecho-option-item-chrome-4').style.display = 'none';
	    document.getElementById('typecho-option-item-sun-5').style.display = 'none';
	    document.getElementById('typecho-option-item-moon-6').style.display = 'none';
	    document.getElementById('typecho-option-item-alicestyle-7').style.display = 'none';
	    document.getElementById('typecho-option-item-kirinshiki-8').style.display = 'none';
	    document.getElementById('typecho-option-item-footer-9').style.display = 'none';
	    document.getElementById('typecho-option-item-phonebutton-10').style.display = 'none';
	    document.getElementById('typecho-option-item-updateSource-11').style.display = 'none';
	    document.getElementById('typecho-option-item-updateBeta-12').style.display = 'none';
	    document.getElementById('typecho-option-item--13').style.display = 'none';
	} else {
	    if (document.getElementById('mode-0-1').value !== 'time') {
	        document.getElementById('typecho-option-item-start-1').style.display = 'none';
	        document.getElementById('typecho-option-item-end-2').style.display = 'none';
	    } else {
	        document.getElementById('typecho-option-item-start-1').style.display = 'block';
	        document.getElementById('typecho-option-item-end-2').style.display = 'block';
	    } if (document.getElementById('mode-0-1').value == 'never') {
	        document.getElementById('typecho-option-item-chrome-3').style.display = 'none';
	        document.getElementById('typecho-option-item-sun-4').style.display = 'none';
	        document.getElementById('typecho-option-item-moon-5').style.display = 'none';
	        document.getElementById('typecho-option-item-alicestyle-6').style.display = 'none';
	        document.getElementById('typecho-option-item-kirinshiki-7').style.display = 'none';
	        document.getElementById('typecho-option-item-footer-8').style.display = 'none';
	        document.getElementById('typecho-option-item-phonebutton-9').style.display = 'none';
	    } else {
	        document.getElementById('typecho-option-item-chrome-3').style.display = 'block';
	        document.getElementById('typecho-option-item-sun-4').style.display = 'block';
	        document.getElementById('typecho-option-item-moon-5').style.display = 'block';
	        document.getElementById('typecho-option-item-alicestyle-6').style.display = 'block';
	        document.getElementById('typecho-option-item-kirinshiki-7').style.display = 'block';
	        document.getElementById('typecho-option-item-footer-8').style.display = 'block';
	        document.getElementById('typecho-option-item-phonebutton-9').style.display = 'block';
	    }
	    document.getElementById('typecho-option-item-kirinshiki-7').childNodes[2].previousElementSibling.childNodes[0].nextSibling.style.display = 'none';
	}
}, 0);
</script>
EOF
;


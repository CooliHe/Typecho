<?php

/**
 * <strong style="color:#5e5e5e;font-family:'PingFang','Microsoft YaHei UI','Microsoft YaHei';">Handsome 夜间模式插件<br>更新日期：<code id="darkmode:date" style="padding:2px 4px;background-color:#f9f2f4;border-radius:4px;color:#c7254e;font-family:'PingFang','Microsoft YaHei UI','Microsoft YaHei';font-size:90%;">查询中</code><script> setInterval( function () { if ( sessionStorage.getItem( 'darkmode:date' ) != undefined ) { document.getElementById( 'darkmode:date' ).innerHTML = sessionStorage.getItem( 'darkmode:date' ); } }, 0 ); </script><br>详细说明：<a style="color:#1024eec2;font-family:'PingFang','Microsoft YaHei UI','Microsoft YaHei';" href="https://blog.baoshuo.ren/archives/341.html">https://blog.baoshuo.ren/archives/364.html</a></strong>
 *
 * @package <strong style="background:linear-gradient(to bottom right,#ffb631,#f76b1d);-webkit-background-clip:text;color:transparent;font-family:'PingFang','Microsoft YaHei UI','Microsoft YaHei';">Darkmode for Handsome</strong><style>#plugin-Darkmode{background:#ffffe5;}</style>
 * @author  <a style="background:linear-gradient(to bottom right,#ffb631,#f76b1d);-webkit-background-clip:text;color:transparent;font-family:'PingFang','Microsoft YaHei UI','Microsoft YaHei';" href="https://www.baoshuo.ren/" target="_blank">任宝硕</a><br /><a style="background:linear-gradient(to bottom right,#ffb631,#f76b1d);-webkit-background-clip:text;color:transparent;font-family:'PingFang','Microsoft YaHei UI','Microsoft YaHei';" href="https://www.me.sb/" target="_blank">王公子</a></strong>
 * @version <strong id="darkmode:version" style="color:#5e5e5e;font-family:'PingFang','Microsoft YaHei UI','Microsoft YaHei';">查询中</strong><script> setInterval( function () { if ( sessionStorage.getItem( 'darkmode:version' ) != undefined ) { document.getElementById( 'darkmode:version' ).innerHTML = sessionStorage.getItem( 'darkmode:version' ); } }, 0 ); </script>
 * @name    Darkmode for Handsome
 * @link    https://blog.baoshuo.ren/archives/341.html
 * @authors 任宝硕(www.baoshuo.ren), 王公子(www.me.sb)
 */

define( 'PINFO',   json_decode( file_get_contents( __dir__ . '/package.json' ), true ) );
define( 'SERVERS', json_decode( file_get_contents( __dir__ . '/update.json'  ), true ) );

class Darkmode_Plugin implements Typecho_Plugin_Interface {
    
    /**
     * Set activate() function
     * 
     * @access public
     * @return string
     * @throws Typecho_Plugin_Exception
     */
    public static function activate() {
        Typecho_Plugin::factory( 'Widget_Archive' )->header = array( __CLASS__, 'header' );
        Typecho_Plugin::factory( 'Widget_Archive' )->footer = array( __CLASS__, 'footer' );
        Typecho_Plugin::factory( 'admin/header.php' )->end  = array( __CLASS__, 'adminHeader' );
        Typecho_Plugin::factory( 'admin/footer.php' )->end  = array( __CLASS__, 'adminFooter' );
        Helper::addRoute( 'route_Darkmode', 'Darkmode', 'Darkmode_Action','action');
        return _t( '夜间模式已启用，如需帮助请前往 <a href="https://blog.baoshuo.ren/archives/341.html" target="_blank">Darkmode 主页</a> 评论反馈' );
    }
    
    /**
     * Set deactivate() function
     * 
     * @static
     * @access public
     * @return string
     * @throws Typecho_Plugin_Exception
     */
    public static function deactivate() {
        Helper::removeRoute( 'route_Darkmode' );
        return _t( '夜间模式已卸载，若我们做的有什么不足，请到 <a href="https://blog.baoshuo.ren/archives/341.html" target="_blank">Darkmode 主页</a> 评论反馈' );
    }
    
    /**
     * Set plugin configuration panel
     * 
     * @access public
     * @param  Typecho_Widget_Helper_Form $form 配置面板
     * @return void
     */
    public static function config( Typecho_Widget_Helper_Form $form ) {
        
        
        
        
        
        if ( isset( $_GET['action'] ) && $_GET['action'] == 'DoUpdate' ) {
            
            $options['updateSource'] = Helper::options()->plugin( 'Darkmode' )->updateSource;
            $options['updateBeta']   = Helper::options()->plugin( 'Darkmode' )->updateBeta;
            
            if ( SERVERS[$options['updateSource']]['ssl'] == true ) {
                $serverSSL = 's';
            }
            $updateData = 'http' . $serverSSL . '://' . SERVERS[$options['updateSource']]['domain'] . '/update';
            
            $updateData = self::http_request( $updateData );
            $updateData = json_decode( $updateData, true );
            
            if ( $options['updateBeta'][0] == 'on' ) {
                $updateBranch = '&beta=1';
            }
            
            $updateList = 'http' . $serverSSL . '://' . SERVERS[$options['updateSource']]['domain'] . '/last?get=list' . $updateBranch;
            
            $updateList = self::http_request( $updateList );
            $updateList = json_decode( $updateList, true );
            
            foreach ( scandir( __dir__ ) as $pluginFile ) {
                if ( $pluginFile != '.' && $pluginFile != '..' ) {
                    @unlink( __dir__ . '/' . $pluginFile );
                }
            }
            
            foreach ( $updateList as $updateFile ) {
                
                $sourceURI = 'http' . $serverSSL . '://' . SERVERS[$options['updateSource']]['domain'] . '/last?get=' . $updateFile . $updateBranch;
                $filePath = __dir__ . '/' . $updateFile;
                
                $fileContents = self::http_request( $sourceURI );
                file_put_contents( $filePath, $fileContents );
                
            }
            
            header( 'Location: ' . Typecho_Common::url( '/options-plugin.php?config=Darkmode', Helper::options()->adminUrl ) );
            exit();
            
        } elseif ( isset( $_GET['action'] ) && $_GET['action'] == 'CheckUpdate' ) {
            
            $options['updateSource'] = Helper::options()->plugin( 'Darkmode' )->updateSource;
            $options['updateBeta']   = Helper::options()->plugin( 'Darkmode' )->updateBeta;
            
            if ( SERVERS[$options['updateSource']]['ssl'] == true ) {
                $serverSSL = 's';
            }
            $updateData = 'http' . $serverSSL . '://' . SERVERS[$options['updateSource']]['domain'] . '/update';
            
            $updateData = self::http_request( $updateData );
            $updateData = json_decode( $updateData, true );
            
            if ( $options['updateBeta'][0] == 'on' ) {
                $updateBranch = 'beta';
            } else {
                $updateBranch = 'releases';
            }
            
            $updateStatus = self::versionCompare( PINFO['version'], $updateData[$updateBranch]['version']);
            
            if ($updateStatus == -1) {
                $updateValue = '更新至最新版本';
                $updateDescription = '，发现可用的最新版本：' . $updateData[$updateBranch]['version'].'<br><b style="font-size:130%;">更新简介</b><br>'.$updateData[$updateBranch]['description'].'';
                $updateAction = '/options-plugin.php?config=Darkmode&action=DoUpdate';
            } else {
                $updateValue = '无需更新，点击返回';
                $updateDescription = '，当前版本已是最新版本';
                $updateAction = '/options-plugin.php?config=Darkmode';
            }
            
            $updateBtn = new Typecho_Widget_Helper_Form_Element_Submit();
            $updateBtn->value( _t( $updateValue ) );
            $updateBtn->description( _t( '当前版本：' . PINFO['version'] . $updateDescription . '<br>' ) );
            $updateBtn->setAttribute('class', 'typecho-option');
            $updateBtn->input->setAttribute('class', 'btn btn-s btn-warn btn-operate');
            $updateBtn->input->setAttribute('formaction', Typecho_Common::url($updateAction, Helper::options()->adminUrl));
            $form->addItem($updateBtn);
			echo '<span id="check" style="display:none;"></span>';
        }
        
        require_once __dir__ . '/Config.php';
        
        
        foreach ( SERVERS as $update['source']['id'] => $update['source']['info'] ) {
            $update['source']['list'][$update['source']['id']] = _t( $update['source']['info']['name'] );
        }
        $updateSource = new Typecho_Widget_Helper_Form_Element_Select( 'updateSource', $update['source']['list'], array_keys( $update['source']['list'] )[0], _t( '选择一个服务器节点以获取更新' ), _t( '' ) );
        $form->addInput( $updateSource );
        
        $updateBeta = new Typecho_Widget_Helper_Form_Element_Checkbox( 'updateBeta', array( 'on' => _t( '获取测试版本' ) ), _t( ' ' ), _t( '加入 Beta 计划以帮助我们发现问题' ), _t( '打开此选项可获取测试版更新，<b style="color:red;">注意，测试版本的稳定性较差，请谨慎开启。</b> <br>关闭开关后会在下一个大于当前版本号的正式版本自动退出。' ) );
        $form->addInput( $updateBeta );
        if(!isset($_GET['action'])) {
            $updateAction = '/options-plugin.php?config=Darkmode&action=CheckUpdate';
            $updateBtn = new Typecho_Widget_Helper_Form_Element_Submit();
            $updateBtn->value( _t( '检查更新' ) );
            $updateBtn->description( _t( '当前版本：' . PINFO['version'] . '<br><font color="red">请点击上方按钮检查更新</font>' ) );
            $updateBtn->setAttribute( 'class', 'typecho-option' );
            $updateBtn->input->setAttribute( 'class', 'btn btn-s btn-warn btn-operate' );
            $updateBtn->input->setAttribute( 'formaction', Typecho_Common::url( $updateAction, Helper::options()->adminUrl ) );
            $form->addItem( $updateBtn );
            
        }
        
        echo '<script> document.title = \'Darkmode for Handsome v' . PINFO['version'] . '\'; </script>';
        echo '<script> console.log( \'\n %c Darkmode for Handsome v' . PINFO['version'] . ' \', \'color: #ffffff; background: linear-gradient(to right , #ffb631, #f76b1d); padding: 5px; border-radius: 10px;\', \'\n\n作者: 任宝硕(www.baoshuo.ren), 王公子(www.me.sb)\n \' ); </script>';
        
    }
    
    /**
     * Set plugin configuration panel for other users
     * 
     * @access public
     * @param Typecho_Widget_Helper_Form $form
     * @return void
     */
    public static function personalConfig( Typecho_Widget_Helper_Form $form ) {}
    
    /**
     * Plugin implementation method
     * 
     * @access public
     * @return void
     */
    public static function render() {
        require_once __dir__ . '/Render.php';
    }
    
    /**
     * Set headers
     * @return void
     */
    public static function header() {
        require_once __dir__ . '/Header.php';
    }
    
    /**
     * Set footers
     * @return void
     */
    public static function footer() {
        require_once __dir__ . '/Footer.php';
    }
    
    public static function adminHeader(){
        require_once __dir__ . '/adminHeader.php';
    }
    
    public static function adminFooter(){
        require_once __dir__ . '/adminFooter.php';
    }
    
    public static function http_request( $url, $data = null ) {
        $curl = curl_init();
        curl_setopt( $curl, CURLOPT_URL, $url );
        curl_setopt( $curl, CURLOPT_SSL_VERIFYPEER, false );
        curl_setopt( $curl, CURLOPT_SSL_VERIFYHOST, false );
        if ( ! empty( $data ) ) {
            curl_setopt( $curl, CURLOPT_POST, 1 );
            curl_setopt( $curl, CURLOPT_POSTFIELDS, $data );
        }
        curl_setopt( $curl, CURLOPT_RETURNTRANSFER, 1 );
        $result = curl_exec( $curl );
        curl_close( $curl );
        return $result;
    }
    
    public static function versionCompare( $v1, $v2 ) {
        function reg( $str ) {
            return preg_replace( '/[^0-9]/', '', $str );
        }
        function add( $str, $length ) {
            return str_pad( $str, $length, '0' );
        }
        $length = strlen( reg( $v1 ) ) > strlen( reg( $v2 ) ) ? strlen( reg( $v1 ) ) : strlen( reg( $v2 ) );
        $v1 = add( reg( $v1 ), $length );
        $v2 = add( reg( $v2 ), $length );
        if ( $v1 == $v2 ) {
            return 0;
        } else {
            return $v1 > $v2 ? 1 : -1;
        }
    }
    
}
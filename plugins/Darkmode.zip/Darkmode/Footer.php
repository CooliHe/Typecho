<?php

/**
 * 
 * @package Darkmode
 * @author 任宝硕(www.baoshuo.ren), 王公子(www.me.sb)
 */

/** 获取配置 */
$mode        = Helper::options()->plugin( 'Darkmode' )->mode;
$start       = Helper::options()->plugin( 'Darkmode' )->start;
$end         = Helper::options()->plugin( 'Darkmode' )->end;
$phonebutton = Helper::options()->plugin( 'Darkmode' )->phonebutton;


if ( $mode != 'never' ) {
    
    /** 动态插入切换按钮 */
    echo '<!-- Darkmode Plugin v' . DARKINFO['version'] . ' - Add Buttons -->';
    echo '<script>var darkbtn = document.createElement(\'li\');darkbtn.innerHTML=\'<a class="nav-switch-dark-mode for-desktop" href="javascript:"><span class="icon-light-mode" data-toggle="tooltip" data-placement="bottom" title="" data-original-title=" 夜晚模式 "><i data-feather="moon"></i><span class="visible-xs-inline"> 夜晚模式</span></span><span class="icon-dark-mode" style="display: none;" data-toggle="tooltip" data-placement="bottom" title="" data-original-title=" 日间模式 "><i data-feather="sun"></i><span class="visible-xs-inline"> 日间模式</span></span></a>\';var darkdiv = document.getElementById(\'easyLogin\').parentElement;darkdiv.insertBefore(darkbtn,document.getElementById(\'easyLogin\'));</script>';
    
    if ( $phonebutton == 'headnav' ) {
        echo '<!-- Darkmode Plugin v' . DARKINFO['version'] . ' - Add Buttons For Mobile -->';
        echo '<script>var darkbtn2 = document.createElement(\'button\');darkbtn2.classList = \'pull-right visible-xs\';darkbtn2.innerHTML=\'<a class="nav-switch-dark-mode" href="javascript:"><span class="icon-light-mode" data-toggle="tooltip" data-placement="bottom" title=""><i data-feather="moon"></i></span><span class="icon-dark-mode" data-toggle="tooltip" data-placement="bottom" title=""><i data-feather="sun"></i></span></a>\';var darkdiv2 = document.querySelectorAll(\'.navbar-header\').item(0);darkdiv2.insertBefore(darkbtn2,darkdiv2.childNodes[2]);</script>';
    }

    /** 插入 JavaScript 脚本 */
    echo '<!-- Darkmode Plugin v' . DARKINFO['version'] . ' - Darkmode JS -->';
    if ( $mode === 'cookie' ) {
        echo '<script>(function(){if(document.cookie.replace(/(?:(?:^|.*;\s*)night\s*\=\s*([^;]*).*$)|^.*$/, "$1") === \'\'){if(new Date().getHours() >= ' . $start . ' || new Date().getHours() < ' . $end . '){$(\'body\').toggleClass(\'night\');$(\'html\').toggleClass(\'night\');$(\'.icon-light-mode\').css(\'display\',\'none\');$(\'.icon-dark-mode\').css(\'display\',\'block\');document.cookie = "night=1;path=/";console.log(\'夜间模式开启\');}else{$(\'body\').removeClass(\'night\');$(\'html\').removeClass(\'night\');$(\'.icon-light-mode\').css(\'display\',\'block\');$(\'.icon-dark-mode\').css(\'display\',\'none\');document.cookie = "night=0;path=/";console.log(\'夜间模式关闭\');}}else{var night = document.cookie.replace(/(?:(?:^|.*;\s*)night\s*\=\s*([^;]*).*$)|^.*$/, "$1") || \'0\';if(night == \'0\'){$(\'body\').removeClass(\'night\');$(\'html\').removeClass(\'night\');$(\'.icon-light-mode\').css(\'display\',\'block\');$(\'.icon-dark-mode\').css(\'display\',\'none\');}else if(night == \'1\'){$(\'body\').toggleClass(\'night\');$(\'html\').toggleClass(\'night\');$(\'.icon-light-mode\').css(\'display\',\'none\');$(\'.icon-dark-mode\').css(\'display\',\'block\');}}})();function switchNightMode(){var night = document.cookie.replace(/(?:(?:^|.*;\s*)night\s*\=\s*([^;]*).*$)|^.*$/, "$1") || \'0\';if(night == \'0\'){$(\'body\').toggleClass(\'night\');$(\'html\').toggleClass(\'night\');$(\'.icon-light-mode\').css(\'display\',\'none\');$(\'.icon-dark-mode\').css(\'display\',\'block\');document.cookie = "night=1;path=/";console.log(\'夜间模式开启\');}else{$(\'body\').removeClass(\'night\');$(\'html\').removeClass(\'night\');$(\'.icon-light-mode\').css(\'display\',\'block\');$(\'.icon-dark-mode\').css(\'display\',\'none\');document.cookie = "night=0;path=/";console.log(\'夜间模式关闭\');}}$(document).on(\'click\',\'.nav-switch-dark-mode\',function(event){event.preventDefault();switchNightMode();});</script>';
    } elseif ( $mode == 'time' ) {
        echo '<script>(function(){if(new Date().getHours()>=' . $start . ' || new Date().getHours()<' . $end . '){$(\'body\').toggleClass(\'night\');$(\'html\').toggleClass(\'night\');$(\'.icon-light-mode\').css(\'display\',\'none\');$(\'.icon-dark-mode\').css(\'display\',\'block\');document.cookie = "night=1;path=/";console.log(\'夜间模式开启\');}else{$(\'body\').removeClass(\'night\');$(\'html\').removeClass(\'night\');$(\'.icon-light-mode\').css(\'display\',\'block\');$(\'.icon-dark-mode\').css(\'display\',\'none\');document.cookie = "night=0;path=/";console.log(\'夜间模式关闭\');}})();function switchNightMode(){var night = document.cookie.replace(/(?:(?:^|.*;\s*)night\s*\=\s*([^;]*).*$)|^.*$/, "$1") || \'0\';if(night == \'0\'){$(\'body\').toggleClass(\'night\');$(\'html\').toggleClass(\'night\');$(\'.icon-light-mode\').css(\'display\',\'none\');$(\'.icon-dark-mode\').css(\'display\',\'block\');document.cookie = "night=1;path=/";console.log(\'夜间模式开启\');}else{$(\'body\').removeClass(\'night\');$(\'html\').removeClass(\'night\');$(\'.icon-light-mode\').css(\'display\',\'block\');$(\'.icon-dark-mode\').css(\'display\',\'none\');document.cookie = "night=0;path=/";console.log(\'夜间模式关闭\');}}$(document).on(\'click\',\'.nav-switch-dark-mode\',function(event){event.preventDefault();switchNightMode();});</script>';
    } elseif ($mode == 'always') {
        echo '<script>(function(){$(\'body\').toggleClass(\'night\');$(\'html\').toggleClass(\'night\');$(\'.icon-light-mode\').css(\'display\',\'none\');$(\'.icon-dark-mode\').css(\'display\',\'block\');document.cookie = "night=1;path=/";console.log(\'夜间模式开启\');})();function switchNightMode(){var night=document.cookie.replace(/(?:(?:^|.*;\s*)night\s*\=\s*([^;]*).*$)|^.*$/, "$1") || \'0\';if(night == \'0\'){$(\'body\').toggleClass(\'night\');$(\'html\').toggleClass(\'night\');$(\'.icon-light-mode\').css(\'display\',\'none\');$(\'.icon-dark-mode\').css(\'display\',\'block\');document.cookie = "night=1;path=/";console.log(\'夜间模式开启\');}else{$(\'body\').removeClass(\'night\');$(\'html\').removeClass(\'night\');$(\'.icon-light-mode\').css(\'display\',\'block\');$(\'.icon-dark-mode\').css(\'display\',\'none\');document.cookie = "night=0;path=/";console.log(\'夜间模式关闭\');}}$(document).on(\'click\',\'.nav-switch-dark-mode\',function(event){event.preventDefault();switchNightMode();});</script>';
    }
}

/** 插入控制台标识 */
echo '<!-- Darkmode Plugin v' . DARKINFO['version'] . ' - JS Label -->';
echo '<script> console.log( \'\n %c Darkmode for Handsome v' . PINFO['version'] . ' \', \'color: #ffffff; background: linear-gradient(to right , #ffb631, #f76b1d); padding: 5px; border-radius: 10px;\', \'\n\n作者: 任宝硕(www.baoshuo.ren), 王公子(www.me.sb)\n \' ); </script>';

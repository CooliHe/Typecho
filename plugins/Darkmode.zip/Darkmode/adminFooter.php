<?php

echo '<script> sessionStorage.setItem( \'darkmode:date\', \'' . PINFO['date'] . '\' ); sessionStorage.setItem( \'darkmode:version\', \'' . PINFO['version'] . '\' ); </script>';
